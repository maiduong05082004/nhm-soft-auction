<div class="">
    <ol>
        <li>
            <a href="{{ route('home') }}">
                <span>
                    <i class="fa-solid fa-house"></i>
                </span>
                <span>Trang chủ</span>
            </a>
        </li>
        <li>
            <a href="{{ route('products.index') }}">
                <span>
                    <i class="fa-solid fa-house"></i>
                </span>
                <span>Sản phẩm</span>
            </a>
        </li>
    </ol>
</div>
