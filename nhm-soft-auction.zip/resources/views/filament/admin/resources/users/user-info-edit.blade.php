<x-filament-panels::page>
    {{-- Content --}}
    @livewire('filament.customer-info-edit')
</x-filament-panels::page>
