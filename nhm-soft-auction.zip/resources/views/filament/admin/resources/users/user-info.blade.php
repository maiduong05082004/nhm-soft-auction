<x-filament-panels::page>
    {{-- Content --}}
    @livewire('filament.customer-info-view')
</x-filament-panels::page>
