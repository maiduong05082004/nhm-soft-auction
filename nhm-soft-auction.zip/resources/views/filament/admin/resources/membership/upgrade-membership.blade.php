<x-filament-panels::page>
    @livewire('filament.upgrade-membership')
</x-filament-panels::page>
