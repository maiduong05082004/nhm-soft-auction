<x-filament-panels::page>
    @livewire('filament.buy-membership')
</x-filament-panels::page>
