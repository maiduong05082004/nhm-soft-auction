<x-filament-panels::page>
    @livewire('filament.view-membership')
</x-filament-panels::page>
