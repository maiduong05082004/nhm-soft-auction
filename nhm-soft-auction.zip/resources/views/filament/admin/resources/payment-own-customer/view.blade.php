<x-filament-panels::page>
    @livewire('filament.payment-own-customer-view')
</x-filament-panels::page>
