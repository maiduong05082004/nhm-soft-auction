<x-filament-panels::page>
    @livewire('filament.buy-point-package')
</x-filament-panels::page>
