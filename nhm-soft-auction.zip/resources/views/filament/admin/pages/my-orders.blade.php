<x-filament::page>
    {{ $this->table }}
</x-filament::page>


