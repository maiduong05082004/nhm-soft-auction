<div>
    {{ $this->infolist }}
</div>
