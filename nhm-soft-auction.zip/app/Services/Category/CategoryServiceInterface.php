<?php 

namespace App\Services\Category;

use App\Services\BaseServiceInterface;

interface CategoryServiceInterface extends BaseServiceInterface{

}