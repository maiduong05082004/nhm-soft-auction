<?php

namespace App\Services\Membership;

use App\Models\MembershipUser;
use App\Services\BaseServiceInterface;

interface MembershipServiceInterface extends BaseServiceInterface
{
    public function getAllMembershipPlan();

    public function getMembershipPlanById($id);

    public function createMembershipForUser($userId, $membershipPlan, $dataTransfer): bool;

    public function reActivateMembershipForUser(MembershipUser $membershipUser): bool;

    public function validateActiveMembership(MembershipUser $item): bool;

    public function payByPointsForMembershipUser($userId, $dataTransfer): bool;

    public function getMembershipTransactionByUserId($userId);

    public function updateMembershipForUser($userId, $membershipPlan, $dataTransfer, $payType, $isUpgrade);

    public function checkMembershipExpired(): int;
    
    public function remindMembershipExpiringSoon(int $daysBefore = 3): int;
    
    public function refreshMemberShipTransaction($userId, $orderCode): int;
}
