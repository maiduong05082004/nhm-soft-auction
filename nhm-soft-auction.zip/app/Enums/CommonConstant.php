<?php

namespace App\Enums;

final class CommonConstant
{
    const ACTIVE = 1;

    const INACTIVE = 0;
}
