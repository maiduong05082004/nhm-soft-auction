<?php

namespace App\Enums\Permission;

enum PermissionConstant: string
{

}
