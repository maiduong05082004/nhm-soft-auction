<?php

namespace App\Enums\Permission;

enum RoleConstant: string
{
    case ADMIN = 'admin';
    case CUSTOMER = 'customer';
}
