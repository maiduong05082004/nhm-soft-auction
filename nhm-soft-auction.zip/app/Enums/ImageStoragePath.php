<?php

namespace App\Enums;

enum ImageStoragePath: string
{
    case AVATAR_USER = 'avatar-user';
}
