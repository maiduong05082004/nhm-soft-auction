<?php

namespace App\Repositories\Categories;

use App\Repositories\BaseRepositoryInterface;

interface CategoryRepositoryInterface extends BaseRepositoryInterface
{

    public function getTreeList();
}