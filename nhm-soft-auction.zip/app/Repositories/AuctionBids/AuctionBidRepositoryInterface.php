<?php

namespace App\Repositories\AuctionBids;

use App\Repositories\BaseRepositoryInterface;

interface AuctionBidRepositoryInterface extends BaseRepositoryInterface
{
}