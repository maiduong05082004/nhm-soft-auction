<?php

namespace App\Repositories\ProductImages;

use App\Repositories\BaseRepositoryInterface;

interface ProductImageRepositoryInterface extends BaseRepositoryInterface
{
}
