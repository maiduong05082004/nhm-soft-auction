<?php

namespace App\Repositories\MembershipTransaction;

use App\Repositories\BaseRepositoryInterface;

interface MembershipTransactionRepositoryInterface extends BaseRepositoryInterface
{

}
