<?php

namespace App\Repositories\BannerTypes;

use App\Repositories\BaseRepositoryInterface;

interface BannerTypeRepositoryInterface extends BaseRepositoryInterface
{
    
}
