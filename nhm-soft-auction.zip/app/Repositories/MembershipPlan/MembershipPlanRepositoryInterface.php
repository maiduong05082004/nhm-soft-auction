<?php

namespace App\Repositories\MembershipPlan;

use App\Repositories\BaseRepositoryInterface;

interface MembershipPlanRepositoryInterface extends BaseRepositoryInterface
{

}
