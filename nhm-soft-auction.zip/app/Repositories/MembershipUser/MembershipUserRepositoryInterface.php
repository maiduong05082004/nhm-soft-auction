<?php

namespace App\Repositories\MembershipUser;

use App\Repositories\BaseRepositoryInterface;

interface MembershipUserRepositoryInterface extends BaseRepositoryInterface
{

}
