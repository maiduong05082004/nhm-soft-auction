<?php

namespace App\Repositories\Banners;

use App\Repositories\BaseRepositoryInterface;

interface BannerRepositoryInterface extends BaseRepositoryInterface
{
    
}
