<?php

namespace App\Repositories\PointPackage;

use App\Repositories\BaseRepositoryInterface;

interface PointPackageRepositoryInterface extends BaseRepositoryInterface {
    
}