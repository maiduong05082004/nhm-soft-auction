<?php

namespace App\Repositories\CreditCards;

use App\Repositories\BaseRepositoryInterface;

interface CreditCardRepositoryInterface extends BaseRepositoryInterface
{
}


